package com.example.dns;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DnsApplicationTests {

    @Test
    void contextLoads() {
    }

}
