package com.example.dns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DnsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DnsApplication.class, args);
    }

}
