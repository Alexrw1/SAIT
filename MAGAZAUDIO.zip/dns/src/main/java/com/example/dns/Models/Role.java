package com.example.dns.Models;

public enum Role {
    USER,
    ADMIN,
    EMPLOYEE;


}
