package com.example.api_yp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ApiYpApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiYpApplication.class, args);
    }

}
