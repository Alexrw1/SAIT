package com.example.api_yp.Models;

public enum Role {
    USER,
    ADMIN,
    EMPLOYEE;


}
