package com.example.api_yp.Repositories;

import com.example.api_yp.Models.Shop;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShopRepository extends JpaRepository<Shop,Long> {
}
