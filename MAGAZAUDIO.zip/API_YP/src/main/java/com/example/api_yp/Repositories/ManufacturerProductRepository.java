package com.example.api_yp.Repositories;

import com.example.api_yp.Models.ManufacturerProduct;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManufacturerProductRepository extends JpaRepository<ManufacturerProduct,Long> {
}
