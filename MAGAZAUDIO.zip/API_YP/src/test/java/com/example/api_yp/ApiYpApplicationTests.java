package com.example.api_yp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiYpApplicationTests {

    @Test
    void contextLoads() {
    }

}
